import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.green,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'smart enerji'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final databaseReference = FirebaseDatabase.instance.reference();

  double ledOn = 0;

  double ledOff = 0;

  @override
  void initState() {
    super.initState();

    databaseReference.child("ledStatus").once().then((DataSnapshot snapshot) {
      ledOn = snapshot.value['ledOn'].toDouble();

      ledOff = snapshot.value['ledOff'].toDouble();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title,style: TextStyle(fontSize: 30),),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              margin: EdgeInsets.all(30),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(50)),
                color: ledOn == 1 ? Colors.green : Colors.red,
              ),
              child: SizedBox(
                width: 100,
                height: 100,
              ),
            ),
            RaisedButton(
              child: Text("Turn On the Led",
                  style: TextStyle(
                      color: Colors.white,
                      fontStyle: FontStyle.italic,
                      fontSize: 20.0)),
              color: Colors.green,
              onPressed: _turnOnLed,
            ),
            RaisedButton(
              child: Text("Turn Off the Led",
                  style: TextStyle(
                      color: Colors.white,
                      fontStyle: FontStyle.italic,
                      fontSize: 20.0)),
              color: Colors.red,
              onPressed: _turnOffLed,
            ),
          ],
        ),
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  void _turnOnLed() {
    databaseReference.child("ledStatus").update({
      'ledOn': 1,
    });

    databaseReference.child("ledStatus").update({
      'ledOff': 0,
    });

    setState(() {
      ledOn =1;
      ledOff =0;
    });
  }

  void _turnOffLed() {
    databaseReference.child("ledStatus").update({
      'ledOff': 1,
    });

    databaseReference.child("ledStatus").update({
      'ledOn': 0,
    });

    setState(() {
      ledOn =0;
      ledOff =1;
    });
  }
}
